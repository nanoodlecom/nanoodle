# Iron Verdict

A three-round furnace arena brawler using the generated furnace knight. Open `index.html` through a static HTTP server. No build step, external libraries, API key or network services are required to play.

- A/D or arrows: move
- Space: jump
- J: punch
- K: heavy strike; airborne K: ground slam
- Shift: dodge
- R: restart

Sound begins after pressing Start. Sound and camera-motion controls are in the header; touch controls appear on touch devices.

The game reuses the existing generated body parts. Eight new jump poses were baked locally, with anticipation, rise, apex, fall and landing phases. The game applies gravity to the world position rather than playing a baked vertical trajectory. The included atlas has 32 transparent 256×256 frames, with the original idle/walk/punch frames unchanged. No additional generation calls were made.

Character art is a cutout prototype with rigid elbows and knees. Enemies reuse the same character with different treatments. Combat effects and the environment are rendered locally in Canvas; sounds use Web Audio synthesis.

Gravity is 3,200 pixels/s² with an initial jump velocity of −890 pixels/s. Ground landing has 130 ms recovery. Slam has a 1.3-second cooldown; dodge has a 1.15-second cooldown. Armor restores by 18 between rounds. Heavy strikes interrupt windups; attacks have directional range and recovery, and enemy attacks lock facing during their telegraph.

## Verification

Eleven browser checks passed: jump physics, exact floor contact and landing recovery, blocked jump cancellation, dodge cooldown, settings, defeat, restart button/key, mobile layout, real touch jump and no runtime exceptions. Two normal-input playthroughs exercised balance: jump/slam repetition died in round three; timed heavy strikes with dodges defeated all nine opponents and reached victory. Reports and screenshots are in `review/`. This is a local prototype, not a claim of broad device or difficulty testing. The audio implementation was exercised, but its subjective mix has not been independently auditioned.

Sprite validation checked eight unique transparent jump frames, 32 correct atlas entries and byte-identical original 24 frames. The skill validator and JavaScript syntax check passed.
